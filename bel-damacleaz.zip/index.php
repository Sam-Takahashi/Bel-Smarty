<?php
include('includes/class-autoload.inc.php');
require_once('templates/header.php');
?>
<!-- header fin -->


<!-- Recipe-Template -->
<h1 style="text-align: center; color: red;">Metis Test Site</h1>
<?php
require_once('templates/recipe-template.php')
?>


<!-- content(class) -->


<?php
require_once('templates/footer.php')
?>