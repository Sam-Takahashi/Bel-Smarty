    <!-- need to implement an autoload system to load css -->
  

    <?php
    //include('./includes/class-autoload.inc.php');
    require_once('./templates/header.php');
    ?>


    <?php
    require_once('./templates/recipe-list-template.php')
    ?>


    <?php
    require_once('./templates/footer.php')
    ?>