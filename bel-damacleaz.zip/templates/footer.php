<!-- content -->
</div>
<!-- container(class) -->
</div>

<!-- footer -->
<div id="foot">
    <div class="inner">
        <p class="copys">
            <a href="#">» コーポレート情報</a>
            <a href="#">» プレスリリース</a>
            <a href="#">» CSRへの取り組み</a>
            <a href="#">» サイトマップ</a>
            <a href="#">» ご利用規約</a>
            <br>
            copyright © Metis Flow
        </p>

        <span class="p-top">
            <a href="#top"><img src="./img/pagetop.png" width="100%" alt="ページトップへ"></a>
        </span>
    </div>
</div>

<script src="js/main.js"></script>
</body>


</html>