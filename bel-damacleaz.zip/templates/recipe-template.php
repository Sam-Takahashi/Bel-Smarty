<!--Content Body -->
<img src="./img/mainImage.png" width="100%" alt="bel recipe">


<!-- <h2 style="text-align: center; color: red;">INDEX PAGE</h2> -->
<ul id="recipe" class="clearfix">
    <li class="tops">
        <a href="#">
            <img src="./img/0109_pu.jpg" width="100%" alt="">
            <p class="" style="min-height: 39px;">鶏肉のカレークリームチーズ焼き</p>

        </a>
    </li>
    <li class="tops">
        <a href="#">
            <img src="./img/0337_pu.jpg" width="100%" alt="">
            <p class="wht" style="min-height: 39px;">牛肉のタリアータ<br>クレソンのサラダとブルサン添え</p>

        </a>
    </li>
    <li class="tops">
        <a href="#">
            <img src="./img/top_mail.jpg" width="100%" alt="">
            <p class="wht" style="min-height: 39px;">メールマガジンでレシピや<br>キャンペーン情報が届く!!</p>

        </a>
    </li>
    <li>
        <a href="./recipe-list.php">
            <img src="./img/top_boursin.jpg" width="100%" alt="">
            <p class="" style="min-height: 39px;">ブルサンを使って</p>

        </a>
    </li>
    <li>
        <a href="./recipe-list.php">
            <img src="./img/top_boursin.jpg" width="100%" alt="">
            <p class="" style="min-height: 39px;">ブルサンを使って</p>

        </a>
    </li>
    <li>
        <a href="./recipe-list.php">
            <img src="./img/top_boursin.jpg" width="100%" alt="">
            <p class="" style="min-height: 39px;">ブルサンを使って</p>

        </a>
    </li>
    <li>
        <a href="./recipe-list.php">
            <img src="./img/top_boursin.jpg" width="100%" alt="">
            <p class="" style="min-height: 39px;">ブルサンを使って</p>

        </a>
    </li>
    <li>
        <a href="./recipe-list.php">
            <img src="./img/top_boursin.jpg" width="100%" alt="">
            <p class="" style="min-height: 39px;">ブルサンを使って</p>

        </a>
    </li>
    <li>
        <a href="./recipe-list.php">
            <img src="./img/top_boursin.jpg" width="100%" alt="">
            <p class="" style="min-height: 39px;">ブルサンを使って</p>

        </a>
    </li>
</ul>


<div class="line">
    <img src="./img/gline.png" width="100%" alt="">
</div>

<div class="banner">
    <a href="#">
        <img src="./img/bnr_pro.png" width="100%" alt=" プロフェッショナルの方向けレシピはこちら">
    </a>
</div>