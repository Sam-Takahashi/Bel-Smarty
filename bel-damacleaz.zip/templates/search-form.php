        <section class="search-form">
            <div class="">
                <form action="./search-results.php" method="POST">
                    <input type="search" name="search" placeholder="Search for Food.." class="search-input">
                    <input type="submit" name="submit" value="Search" class="search-btn">
                </form>

            </div>
        </section>